﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Cekilis_Programi
{



    public partial class Form1 : Form
    {


        int cekilisSay = 1;
        public Form1()
        {
            InitializeComponent();
        }

        private void rtx_adaylar_TextChanged(object sender, EventArgs e)
        {
            lblCekilisSayi.Text = rtxAdaylar.Lines.Count().ToString();

            if (rtxAdaylar.Lines.Count()>0 )
            {
                nMiktar.Maximum = rtxAdaylar.Lines.Count()-1;
            }
            else
            {
                nMiktar.Minimum= 1;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtgList.ColumnCount = 2;
            dtgList.Columns[0].Name = "Sıra No:";
            dtgList.Columns[1].Name = "Adı ve Soyadı:";
            nMiktar.Value = 1;
            this.MaximizeBox = false; // Formun küçültme düğmesini kaldır
        }
        
        private void btn_baslat_Click(object sender, EventArgs e)
        {


            SystemSounds.Beep.Play();


            int cekilisSayisi = Convert.ToInt32(nMiktar.Text);
            List<string> listadaylar = new List<string>(rtxAdaylar.Text.Split('\n')); 


            if (rtxAdaylar.Text=="")
            {
                MessageBox.Show("Liste boş olamaz. Lütfen kontrol edin !", "Uyari !", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Random uret=new Random();

                for (int i = 0; i < cekilisSayisi; i++) 
                
                {

                    int kazananaday = uret.Next(0, listadaylar.Count);
                    dtgList.Rows.Add(cekilisSay++, listadaylar[kazananaday]);
                   
                    listadaylar.Remove(listadaylar[kazananaday]);
                }

            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dtgList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        
        private void btnTemizle_Click(object sender, EventArgs e)
        {
            rtxAdaylar.Clear();
            dtgList.Rows.Clear  ();
            cekilisSay = 1;
            nMiktar.Value = 1;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            dtgList.Rows.Clear();
            cekilisSay = 1;
            nMiktar.Value = 1;
        }

        private void button2_Click(object sender, EventArgs e)
        {




            int cekilisSayisi = Convert.ToInt32(nMiktar.Text);
            List<string> listadaylar = new List<string>(rtxAdaylar.Text.Split('\n'));


            if (rtxAdaylar.Text == "")
            {
                MessageBox.Show("Aday listesi boş! Lütfen Kontrol edin.", "Uyari !");
            }
            else
            {
                Random uret = new Random();

                for (int i = 0; i < cekilisSayisi; i++)

                {

                    int kazananaday = uret.Next(0, listadaylar.Count);
                    dtgList.Rows.Add(cekilisSay++, listadaylar[kazananaday]);
                    listadaylar.Remove(listadaylar[kazananaday]);
                }






            }
        }

        private void btnKapat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
          
            dtgList.Rows.Clear();
            cekilisSay = 1;
            nMiktar.Value = 1;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
